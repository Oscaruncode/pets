
package com.mycompany.peluqueriacanina;
import gui.Principal;

public class PeluqueriaCanina {

    public static void main(String[] args) {
        Principal princ = new Principal ();
        princ.setVisible(true);
        princ.setLocationRelativeTo(null);
    }
}
